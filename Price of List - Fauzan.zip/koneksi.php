<?php
$koneksi = mysqli_connect("localhost", "root", "123", "point_of_sale");

?>
